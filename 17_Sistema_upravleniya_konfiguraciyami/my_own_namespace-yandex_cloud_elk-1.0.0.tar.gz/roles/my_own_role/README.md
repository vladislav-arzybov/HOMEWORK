my_own_role
=========

This role create a new file


Role Variables
--------------

|vars                | description                              |
|--------------------|------------------------------------------|
| path               | Path and name a new file                 |
| content            | Text in file, default text - ```test```  |



Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: my_own_role }

License
-------

MIT

Author Information
------------------

Vladislav Arzybov
